/* eslint no-underscore-dangle: 0 */
import { call, put, takeEvery } from 'redux-saga/effects';
import { isJson } from '../../Utils';
import { requestStartTrial } from '../../services/subscription';
import {
  START_TRIAL_SUBSCRIPTION_REQUEST,
  START_TRIAL_SUBSCRIPTION_SUCCESS,
  START_TRIAL_SUBSCRIPTION_FAIL,
  UPDATE_USER_SUBSCRIPTION,
} from '../constants';

function startTrialSuccess(payload) {
  return { type: START_TRIAL_SUBSCRIPTION_SUCCESS, payload };
}

function startTrialFail(payload) {
  return { type: START_TRIAL_SUBSCRIPTION_FAIL, payload };
}

function updateUserSubscriptionPlan(payload) {
  return { type: UPDATE_USER_SUBSCRIPTION, payload };
}

function* startTrial(aPayload) {
  const { requestPayload } = aPayload;
  const url = 'premium/trial';
  const queryString = {
    ...requestPayload,
  };

  try {
    const resBody = yield call(requestStartTrial, { url, queryString });

    let responseData;

    if (isJson(resBody._bodyText)) {
      responseData = JSON.parse(resBody._bodyText);
    } else {
      responseData = { message: resBody._bodyText };
    }

    let payload;

    if (!resBody.ok) {
      payload = {
        error: responseData,
      };
      yield put(startTrialFail(payload));
    } else {
      payload = {
        data: responseData,
      };
      yield put(startTrialSuccess(payload));
      if (responseData.plan) {
        yield put(updateUserSubscriptionPlan({ plan: responseData }));
      }
    }
  } catch (error) {
    yield put(startTrialFail({ error }));
  }
}

export default function* startTrialSaga() {
  yield takeEvery(START_TRIAL_SUBSCRIPTION_REQUEST, startTrial);
}
