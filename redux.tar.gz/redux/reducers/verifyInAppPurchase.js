import {
  VERIFY_IN_APP_PURCHASE_SUCCESS,
  VERIFY_IN_APP_PURCHASE_FAIL,
  VERIFY_IN_APP_PURCHASE_LOADING,
} from '../constants';

const initialState = {
  data: null,
  inProgress: false,
  error: null,
};

export default function (state = initialState, action) {
  switch (action.type) {
    case VERIFY_IN_APP_PURCHASE_SUCCESS:
    {
      const newState = {
        ...state,
        data: action.payload.data,
        inProgress: false,
        error: null,
      };

      return newState;
    }
    case VERIFY_IN_APP_PURCHASE_FAIL:
      return {
        ...state,
        inProgress: false,
        error: action.payload.error,
      };
    case VERIFY_IN_APP_PURCHASE_LOADING:
      return {
        ...state,
        inProgress: true,
      };
    default:
      return state;
  }
}
