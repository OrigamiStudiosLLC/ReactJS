import {
  FETCH_SUBSCRIPTION_REQUEST,
  FETCH_SUBSCRIPTION_LOADING,
  START_TRIAL_SUBSCRIPTION_REQUEST,
  START_TRIAL_SUBSCRIPTION_LOADING,
} from '../constants';

function fetchUserSubscriptionRequest(requestPayload) {
  return {
    type: FETCH_SUBSCRIPTION_REQUEST,
    requestPayload,
  };
}

function startTrialSubscriptionRequest(requestPayload) {
  return {
    type: START_TRIAL_SUBSCRIPTION_REQUEST,
    requestPayload,
  };
}


export function startTrialSubscription(requestPayload = {}) {
  return (dispatch) => {
    dispatch(startTrialSubscriptionRequest(requestPayload));
    dispatch({ type: START_TRIAL_SUBSCRIPTION_LOADING });
  };
}

export function fetchUserSubscription(requestPayload = {}) {
  return (dispatch) => {
    dispatch(fetchUserSubscriptionRequest(requestPayload));
    dispatch({ type: FETCH_SUBSCRIPTION_LOADING });
  };
}

export default {};
