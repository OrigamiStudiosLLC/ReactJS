import {
  FETCH_WATCHLIST_MOVIES_REQUEST,
  FETCH_WATCHLIST_MOVIES_LOADING,
  FETCH_WATCHLIST_MOVIES_CLEAR,
} from '../constants';

import {
  requestAddMovieToWatchList,
  requestRemoveMovieFromWatchList,
} from '../../services/watchList';

function fetchMoviesRequest(requestPayload) {
  return {
    type: FETCH_WATCHLIST_MOVIES_REQUEST,
    requestPayload,
  };
}

function loaderIndicator() {
  return { type: FETCH_WATCHLIST_MOVIES_LOADING };
}

export function clearWatchListMovies() {
  return { type: FETCH_WATCHLIST_MOVIES_CLEAR };
}

export function addMovieToWatchList(movieSlug) {
  return () => {
    const url = `movies/${movieSlug}/save`;
    return requestAddMovieToWatchList({ url });
  };
}

export function removeMovieFromWatchList(movieSlug) {
  return () => {
    const url = `movies/${movieSlug}/save`;
    return requestRemoveMovieFromWatchList({ url });
  };
}

export function fetchWatchListMovies(requestPayload = {}) {
  return (dispatch) => {
    dispatch(fetchMoviesRequest(requestPayload));
    dispatch(loaderIndicator());
  };
}
