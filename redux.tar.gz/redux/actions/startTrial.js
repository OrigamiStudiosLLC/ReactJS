import {
  START_TRIAL_SUBSCRIPTION_REQUEST,
  START_TRIAL_SUBSCRIPTION_INPROGRESS,
} from '../constants';

function startTrialSubscriptionRequest(requestPayload) {
  return {
    type: START_TRIAL_SUBSCRIPTION_REQUEST,
    requestPayload,
  };
}

function loaderIndicator() {
  return { type: START_TRIAL_SUBSCRIPTION_INPROGRESS };
}

export default function startTrialSubscription(requestPayload = {}) {
  return (dispatch) => {
    dispatch(startTrialSubscriptionRequest(requestPayload));
    dispatch(loaderIndicator());
  };
}
