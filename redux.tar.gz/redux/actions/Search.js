import {
    FETCH_RESULT_REQUEST,
    FETCH_RESULT_SUCCESS,
    FETCH_RESULT_FAIL,
} from '../constants';

function RequestSearch(requestPayload) {
    return {
        type: FETCH_RESULT_REQUEST,
        requestPayload,
    };
}


export function fetchSearchResult(requestPayload = {}) {

    return (dispatch) => {
        dispatch(RequestSearch(requestPayload));
    };
}
