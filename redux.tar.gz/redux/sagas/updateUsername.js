/* eslint no-underscore-dangle: 0 */
import { call, put, takeEvery } from 'redux-saga/effects';
import { isJson } from '../../Utils';
import { requestUpdateUsername } from '../../services/updateUsername';
import {
  UPDATE_USERNAME_REQUEST,
  UPDATE_USERNAME_SUCCESS,
  UPDATE_USERNAME_FAIL,
} from '../constants';

// function updateUserMovieProfile(payload) {
//   return { type: UPDATE_USER_MOVIE_PROFILE, payload };
// }

function updateUsernameSuccess(payload) {
  return { type: UPDATE_USERNAME_SUCCESS, payload };
}

function updateUsernameFail(payload) {
  return { type: UPDATE_USERNAME_FAIL, payload };
}

function* updateUsername(aPayload) {
  const { requestPayload } = aPayload;
  const url = 'me/username';

  try {
    const resBody = yield call(requestUpdateUsername, { url, requestPayload });

    let responseData;

    if (isJson(resBody._bodyText)) {
      responseData = JSON.parse(resBody._bodyText);
    } else {
      responseData = { message: resBody._bodyText };
    }

    console.log('response', responseData);

    let payload;

    if (!resBody.ok) {
      payload = {
        error: responseData,
      };
      yield put(updateUsernameFail(payload));
    } else {
      payload = {
        data: responseData,
        username: requestPayload.username,
      };
      // if (resBody.status === 201) {
      //   yield put(updateUserMovieProfile({ region: requestPayload.region }));
      // }
      yield put(updateUsernameSuccess(payload));
    }
  } catch (error) {
    yield put(updateUsernameFail({ error }));
  }
}

export default function* updateUsernameSaga() {
  yield takeEvery(UPDATE_USERNAME_REQUEST, updateUsername);
}
