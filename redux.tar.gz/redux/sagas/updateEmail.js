/* eslint no-underscore-dangle: 0 */
import { call, put, takeEvery } from 'redux-saga/effects';
import { isJson } from '../../Utils';
import { requestUpdateEmail } from '../../services/updateEmail';
import {
  UPDATE_USER_EMAIL_REQUEST,
  UPDATE_USER_EMAIL_SUCCESS,
  UPDATE_USER_EMAIL_FAIL,
} from '../constants';

// function updateUserMovieProfile(payload) {
//   return { type: UPDATE_USER_MOVIE_PROFILE, payload };
// }

function updateEmailSuccess(payload) {
  return { type: UPDATE_USER_EMAIL_SUCCESS, payload };
}

function updateEmailFail(payload) {
  return { type: UPDATE_USER_EMAIL_FAIL, payload };
}

function* updateEmail(aPayload) {
  const { requestPayload } = aPayload;
  const url = 'me/email';
  console.log('request paylaod', requestPayload);
  try {
    const resBody = yield call(requestUpdateEmail, { url, requestPayload });

    let responseData;

    if (isJson(resBody._bodyText)) {
      responseData = JSON.parse(resBody._bodyText);
    } else {
      responseData = { message: resBody._bodyText };
    }

    let payload;

    if (!resBody.ok) {
      payload = {
        error: responseData,
      };
      yield put(updateEmailFail(payload));
    } else {
      payload = {
        data: responseData,
        email: requestPayload.email,
      };
      // if (resBody.status === 201) {
      //   yield put(updateUserMovieProfile({ region: requestPayload.region }));
      // }
      yield put(updateEmailSuccess(payload));
    }
  } catch (error) {
    yield put(updateEmailFail({ error }));
  }
}

export default function* updateEmailSaga() {
  yield takeEvery(UPDATE_USER_EMAIL_REQUEST, updateEmail);
}
