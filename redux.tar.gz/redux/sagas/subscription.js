/* eslint no-underscore-dangle: 0 */
import { call, put, takeEvery } from 'redux-saga/effects';
import { isJson } from '../../Utils';
import { fetchUserSubscription } from '../../services/subscription';
import {
  FETCH_SUBSCRIPTION_REQUEST,
  FETCH_SUBSCRIPTION_SUCCESS,
  FETCH_SUBSCRIPTION_FAIL,
} from '../constants';

function fetchUserSubscriptionSuccess(payload) {
  return { type: FETCH_SUBSCRIPTION_SUCCESS, payload };
}

function fetchUserSubscriptionFail(payload) {
  return { type: FETCH_SUBSCRIPTION_FAIL, payload };
}

export function* fetchUserSubscriptionRequest(aPayload) {
  const { requestPayload } = aPayload;
  const url = 'premium';
  const queryString = {
    ...requestPayload,
  };

  try {
    const resBody = yield call(fetchUserSubscription, { url, queryString });

    let responseData;

    if (isJson(resBody._bodyText)) {
      responseData = JSON.parse(resBody._bodyText);
    } else {
      responseData = { message: resBody._bodyText };
    }

    let payload;

    if (!resBody.ok) {
      payload = {
        error: responseData,
      };
      yield put(fetchUserSubscriptionFail(payload));
    } else {
      payload = {
        data: responseData,
      };
      yield put(fetchUserSubscriptionSuccess(payload));
    }
  } catch (error) {
    yield put(fetchUserSubscriptionFail({ error }));
  }
}

export default function* fetchUserSubscriptionSaga() {
  yield takeEvery(FETCH_SUBSCRIPTION_REQUEST, fetchUserSubscriptionRequest);
}
