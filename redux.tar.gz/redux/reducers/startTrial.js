import {
  START_TRIAL_SUBSCRIPTION_SUCCESS,
  START_TRIAL_SUBSCRIPTION_FAIL,
  START_TRIAL_SUBSCRIPTION_LOADING,
} from '../constants';

const initialState = {
  data: null,
  inProgress: false,
  error: null,
};

export default function (state = initialState, action) {
  switch (action.type) {
    case START_TRIAL_SUBSCRIPTION_SUCCESS:
    {
      const newState = {
        ...state,
        data: action.payload.data,
        inProgress: false,
        error: null,
      };

      return newState;
    }
    case START_TRIAL_SUBSCRIPTION_FAIL:
      return {
        ...state,
        inProgress: false,
        error: action.payload.error,
      };
    case START_TRIAL_SUBSCRIPTION_LOADING:
      return {
        ...state,
        inProgress: true,
      };
    default:
      return state;
  }
}
