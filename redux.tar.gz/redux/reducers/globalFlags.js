import {
  SET_USER_NEW_SIGN_UP,
  CLEAR_USER_NEW_SIGN_UP,
} from '../constants';


const initialState = {
  userNewSignUp: false,
};

export default function (state = initialState, action) {
  switch (action.type) {
    case SET_USER_NEW_SIGN_UP:
      return {
        ...state,
        userNewSignUp: true,
      };
    case CLEAR_USER_NEW_SIGN_UP:
      return {
        ...state,
        userNewSignUp: false,
      };
    default:
      return state;
  }
}

