import { call, put, takeEvery } from 'redux-saga/effects';
import { fetchWatchListMovies } from '../../services/watchList';
import {
  FETCH_WATCHLIST_MOVIES_REQUEST,
  FETCH_WATCHLIST_MOVIES_SUCCESS,
  FETCH_WATCHLIST_MOVIES_FAIL,

} from '../constants';

function fetchWatchListMoviesSuccess(payload) {
  return { type: FETCH_WATCHLIST_MOVIES_SUCCESS, payload };
}

function fetchWatchListMoviesFail(payload) {
  return { type: FETCH_WATCHLIST_MOVIES_FAIL, payload };
}

function* fetchWatchListMoviesRequest(payload) {
  const { requestPayload, requestPayload: { offset = 0 } } = payload;
  const url = 'me/saved';
  const queryString = {
    ...requestPayload,
  };

  try {
    const resBody = yield call(fetchWatchListMovies, { url, queryString });


    const {
      movies, next, prev, total,
    } = JSON.parse(resBody._bodyText); // eslint-disable-line no-underscore-dangle
    yield put(fetchWatchListMoviesSuccess({
      movies, offset, next, prev, total,
    }));
  } catch (error) {
    yield put(fetchWatchListMoviesFail({ error }));
  }
}

export default function* watchListSaga() {
  yield takeEvery(FETCH_WATCHLIST_MOVIES_REQUEST, fetchWatchListMoviesRequest);
}
