import {
  FETCH_MOVIES_FOR_TASTE_REQUEST,
  TASTE_MOVIES_API_IN_PROGRESS,
} from '../constants';

function fetchMoviesForTasteCalculationRequest() {
  return { type: FETCH_MOVIES_FOR_TASTE_REQUEST };
}

function apiRequestForTasteInProgress() {
  return { type: TASTE_MOVIES_API_IN_PROGRESS };
}

export default function fetchMoviesForTasteCalculation() {
  return (dispatch) => {
    dispatch(fetchMoviesForTasteCalculationRequest());
    dispatch(apiRequestForTasteInProgress());
  };
}
