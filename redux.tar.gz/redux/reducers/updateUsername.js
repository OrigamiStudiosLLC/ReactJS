import {
  UPDATE_USERNAME_SUCCESS,
  UPDATE_USERNAME_FAIL,
  UPDATE_USERNAME_INPROGRESS,
} from '../constants';

const initialState = {
  data: null,
  inProgress: false,
  error: null,
};

export default function (state = initialState, action) {
  switch (action.type) {
    case UPDATE_USERNAME_SUCCESS:
    {
      const newState = {
        ...state,
        data: action.payload.data,
        inProgress: false,
        error: null,
      };

      return newState;
    }
    case UPDATE_USERNAME_FAIL:
      return {
        ...state,
        inProgress: false,
        error: action.payload.error,
      };
    case UPDATE_USERNAME_INPROGRESS:
      return {
        ...state,
        inProgress: true,
      };
    default:
      return state;
  }
}
