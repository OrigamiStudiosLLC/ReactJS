/* eslint no-underscore-dangle: 0 */

import { take, select, call, put, takeEvery, takeLatest } from 'redux-saga/effects';
import { isEmpty } from 'lodash';
import {
  isJson,
} from '../../Utils';
import {
  getGuestAuthToken,
  requestCreateGuestUser,

  requestFetchUserInfo,

  requestCreateMovieProfile,

  requestlocalSignIn,

  convertFacebookTokenToAuthToken,
  requestSignup,
  requestEditPassword,
} from '../../services/auth';
import {
  GUEST_AUTH_REQUEST,
  GUEST_AUTH_SUCCESS,
  GUEST_AUTH_FAIL,

  ACTIVATE_AUTH_LOADER,

  CREATE_GUEST_USER_REQUEST,
  CREATE_GUEST_USER_SUCCESS,
  CREATE_GUEST_USER_FAIL,

  FETCH_USER_INFO_REQUEST,
  FETCH_USER_INFO_SUCCESS,
  FETCH_USER_INFO_FAIL,

  CREATE_MOVIE_PROFILE_REQUEST,
  CREATE_MOVIE_PROFILE_SUCCESS,
  CREATE_MOVIE_PROFILE_FAIL,

  LOCAL_SIGNIN_REQUEST,
  LOCAL_SIGNIN_SUCCESS,
  LOCAL_SIGNIN_FAIL,

  FACEBOOK_SIGNIN_REQUEST,
  SIGNUP_REQUEST,
  SIGNUP_INPROGRESS,
  SIGNUP_SUCCESS,
  SIGNUP_FAIL,
  LOGIN_AFTER_EFFECTS_COMPLETED,
  EDIT_PASSWORD_INPROGRESS,
  EDIT_PASSWORD_SUCCESS,
  EDIT_PASSWORD_FAIL,
  EDIT_PASSWORD_REQUEST,
  SIGN_OUT,
  FETCH_RECOMMENDED_MOVIES_CLEAN,
  FETCH_WATCHLIST_MOVIES_CLEAR,
  FETCH_SEEN_MOVIES_CLEAR,
  FETCH_MOVIES_FOR_TASTE_CLEAR,
} from '../constants';

import API from '../../services/request';

export function activateLoader() {
  return { type: ACTIVATE_AUTH_LOADER };
}

function authTokenTokenSuccess(payload) {
  return { type: GUEST_AUTH_SUCCESS, payload };
}

function authTokenTokenFail(payload) {
  return { type: GUEST_AUTH_FAIL, payload };
}

function* authTokenForGuest() {
  const url = 'me';
  try {
    const guestUserToken = yield call(getGuestAuthToken, { url, requestPayload: { trial: true } });

    const guestToken = JSON.parse(guestUserToken._bodyText);

    yield put(authTokenTokenSuccess({ guestToken }));
  } catch (error) {
    yield put(authTokenTokenFail({ error }));
  }
}

function createGuestUserSuccess(payload) {
  return { type: CREATE_GUEST_USER_SUCCESS, payload };
}

function createGuestUserFail(payload) {
  return { type: CREATE_GUEST_USER_FAIL, payload };
}

function* createGuestUser() {
  try {
    const url = 'me';

    yield put(activateLoader());

    const guestUser = yield call(requestCreateGuestUser, {
      url,
      requestPayload: {
        trial: true,
      },
    });

    yield put(createGuestUserSuccess({ guestUser }));
  } catch (error) {
    yield put(createGuestUserFail({ error }));
  }
}

function fetchUserInfoSuccess(payload) {
  return { type: FETCH_USER_INFO_SUCCESS, payload };
}

function fetchUserInfoFail(payload) {
  return { type: FETCH_USER_INFO_FAIL, payload };
}

function* fetchUserInfo() {
  try {
    const url = 'me';

    yield put(activateLoader());

    const userInfo = yield call(requestFetchUserInfo, { url });

    const newGuest = JSON.parse(userInfo._bodyText);

    yield put(fetchUserInfoSuccess({ newGuest }));
  } catch (error) {
    yield put(fetchUserInfoFail({ error }));
  }
}

function createMovieProfileSuccess(payload) {
  return { type: CREATE_MOVIE_PROFILE_SUCCESS, payload };
}

function createMovieProfileFail(payload) {
  return { type: CREATE_MOVIE_PROFILE_FAIL, payload };
}

export function* createMovieProfile() {
  try {
    const url = 'movies/profile';

    yield put(activateLoader());

    const userProfile = yield call(requestCreateMovieProfile, { url, needsAuthentication: true });

    const userMovieProfile = JSON.parse(userProfile._bodyText);

    yield put(createMovieProfileSuccess({ userMovieProfile }));
  } catch (error) {
    yield put(createMovieProfileFail({ error }));
  }
}

function localSignInSuccess(payload) {
  return { type: LOCAL_SIGNIN_SUCCESS, payload };
}

function localSigninFail(payload) {
  return { type: LOCAL_SIGNIN_FAIL, payload };
}

function* localSignIn(requestPayload) {
  try {
    const url = `${API.baseUrl}/auth/local`;
    const { requestPayload: { email, password } } = requestPayload;

    const userLoginCall = yield call(requestlocalSignIn, {
      url,
      requestPayload: {
        email,
        password,
      },
      customURL: url,
    });

    let payload;
    const userData = userLoginCall;
    let responseData;

    if (isJson(userData._bodyText)) {
      responseData = JSON.parse(userData._bodyText);
    } else {
      responseData = { message: userData._bodyText };
    }

    if (!userData.ok) {
      payload = {
        error: responseData,
      };
      yield put(localSigninFail(payload));
    } else {
      payload = {
        data: responseData,
      };
      yield put(localSignInSuccess(payload));
    }
  } catch (error) {
    yield put(localSigninFail({ error }));
  }
}

function* facebookSignIn(requestPayload) {
  try {
    const customURL = `${API.baseUrl}/auth/facebook/token`;
    // eslint-disable-next-line
    let { requestPayload: { access_token } } = requestPayload;

    const userLoginCall = yield call(convertFacebookTokenToAuthToken, {
      url: '',
      requestPayload: {
        access_token,
      },
      customURL,
    });

    let payload;
    const userData = userLoginCall;
    let responseData;

    if (isJson(userData._bodyText)) {
      responseData = JSON.parse(userData._bodyText);
    } else {
      responseData = { message: userData._bodyText };
    }

    if (!userData.ok) {
      payload = {
        error: responseData,
      };
      yield put(localSigninFail(payload));
    } else {
      payload = {
        data: responseData,
      };
      yield put(localSignInSuccess(payload));
    }
  } catch (error) {
    yield put(localSigninFail({ error }));
  }
}

function* signup(requestPayload) {
  try {
    const { requestPayload: { name, email, password } } = requestPayload;

    yield put({ type: SIGNUP_INPROGRESS });

    const signupCall = yield call(requestSignup, {
      url: 'me',
      requestPayload: {
        name,
        email,
        password,
      },
    });

    let payload;
    const userData = signupCall;
    const responseData = JSON.parse(signupCall._bodyText);

    if (!userData.ok) {
      payload = {
        error: responseData,
      };

      yield put({ type: SIGNUP_FAIL, payload });
    } else {
      payload = {
        error: null,
        data: responseData,
      };

      yield put(localSignInSuccess(payload));
      yield put({ type: SIGNUP_SUCCESS, payload });
    }
  } catch (error) {
    yield put({ type: SIGNUP_FAIL, payload: { error } });
  }
}

/* used for API calls that needs to happen imediatly after successful login */
function* loginAfterEffects() {
  yield take(LOCAL_SIGNIN_SUCCESS);
  try {
    yield call(fetchUserInfo);
    let user = yield select(state => state.auth.currentUser);
    if (isEmpty(user.profile)) {
      throw new Error('fetchUserInfo failed');
    }

    yield call(createMovieProfile);
    user = yield select(state => state.auth.currentUser);
    if (isEmpty(user.movieProfile)) {
      throw new Error('createMovieProfile failed');
    }

    yield put({ type: LOGIN_AFTER_EFFECTS_COMPLETED });
  } catch (e) {
    yield put({ type: LOGIN_AFTER_EFFECTS_COMPLETED });
  }
}

function* editPassword(reqPayload) {
  try {
    const { requestPayload } = reqPayload;

    const url = 'me/password';

    yield put({ type: EDIT_PASSWORD_INPROGRESS });

    const resp = yield call(requestEditPassword, { url, requestPayload });

    let responseData;
    if (isJson(resp._bodyText)) {
      responseData = JSON.parse(resp._bodyText);
    } else {
      responseData = { message: resp._bodyText };
    }

    if (!resp.ok) {
      const payload = {
        error: responseData,
      };
      yield put({ type: EDIT_PASSWORD_FAIL, payload });
    } else {
      const payload = {
        data: responseData,
      };
      yield put({ type: EDIT_PASSWORD_SUCCESS, payload });
    }
  } catch (error) {
    yield put({ type: EDIT_PASSWORD_FAIL, payload: { error } });
  }
}

function* signout() {
  yield put({ type: FETCH_RECOMMENDED_MOVIES_CLEAN });
  yield put({ type: FETCH_WATCHLIST_MOVIES_CLEAR });
  yield put({ type: FETCH_SEEN_MOVIES_CLEAR });
  yield put({ type: FETCH_MOVIES_FOR_TASTE_CLEAR });
}


export default function* authSaga() {
  yield takeEvery(CREATE_GUEST_USER_REQUEST, createGuestUser);
  yield takeEvery(CREATE_MOVIE_PROFILE_REQUEST, createMovieProfile);
  yield takeEvery(FETCH_USER_INFO_REQUEST, fetchUserInfo);
  yield takeEvery(GUEST_AUTH_REQUEST, authTokenForGuest);
  yield takeEvery(LOCAL_SIGNIN_REQUEST, localSignIn);
  yield takeEvery(FACEBOOK_SIGNIN_REQUEST, facebookSignIn);
  yield takeEvery(EDIT_PASSWORD_REQUEST, editPassword);
  yield takeEvery(SIGNUP_REQUEST, signup);
  yield takeEvery(SIGN_OUT, signout);
  yield takeLatest([
    LOCAL_SIGNIN_REQUEST,
    SIGNUP_REQUEST,
    FACEBOOK_SIGNIN_REQUEST], loginAfterEffects);
}
