import {
  FETCH_MOVIES_FOR_TASTE_FAIL,
  FETCH_MOVIES_FOR_TASTE_SUCCESS,
  FETCH_MOVIES_FOR_TASTE_CLEAR,
  TASTE_MOVIES_API_IN_PROGRESS,
  HAS_ONBOARDING_AFTER_EFFECTS_COMPLETED,
} from '../constants';

const initialState = {
  error: null,
  isLoading: false,
  moviesForTaste: [],
  hasOnBoardingAfterEffectsCompleted: false,
};

export default function (state = initialState, action) {
  switch (action.type) {
    case FETCH_MOVIES_FOR_TASTE_SUCCESS:
      return {
        ...state,
        isLoading: false,
        moviesForTaste: action.payload.moviesForTaste,
      };
    case FETCH_MOVIES_FOR_TASTE_FAIL:
      return {
        ...state,
        error: action.payload.error,
        isLoading: false,
      };
    case TASTE_MOVIES_API_IN_PROGRESS:
      return {
        ...state,
        isLoading: true,
      };
    case FETCH_MOVIES_FOR_TASTE_CLEAR:
      return {
        ...initialState,
      };
    case HAS_ONBOARDING_AFTER_EFFECTS_COMPLETED:
      return {
        ...initialState,
        hasOnBoardingAfterEffectsCompleted: true,
      };
    default:
      return state;
  }
}
