/* eslint no-underscore-dangle: 0 */

import { call, put, takeEvery, select } from 'redux-saga/effects';
import { requestRecommendedMovies } from '../../services/recommendations';
import {
  FETCH_RECOMMENDED_MOVIES_REQUEST,
  FETCH_RECOMMENDED_MOVIES_SUCCESS,
  FETCH_RECOMMENDED_MOVIES_FAIL,
  UPDATE_BACKUP_RECOMMENDED_MOVIES_FOR_FREE_USER,
} from '../constants';

function recommendedMoviesSuccess(payload) {
  return { type: FETCH_RECOMMENDED_MOVIES_SUCCESS, payload };
}

function recommendedMoviesFail(payload) {
  return { type: FETCH_RECOMMENDED_MOVIES_FAIL, payload };
}

function updateBackupMoviesForFreeUser(payload) {
  return { type: UPDATE_BACKUP_RECOMMENDED_MOVIES_FOR_FREE_USER, payload };
}

function* fetchRecommendedMovies(payload) {
  const { requestPayload } = payload;
  const url = 'me/matches';

  const { isLoadBackupMovies = false } = requestPayload;
  delete requestPayload.isLoadBackupMovies;

  const queryString = {
    ...requestPayload,
  };
  try {
    const offset = requestPayload.offset ? requestPayload.offset : 0;
    const movies = yield call(requestRecommendedMovies, { url, queryString });

    const recommendedMovies = JSON.parse(movies._bodyText).movies;
    const {
      next, prev, total,
    } = JSON.parse(movies._bodyText);
    // console.log(`${offset}--${recommendedMovies.length}--${total}`);

    if (isLoadBackupMovies) {
      yield put(updateBackupMoviesForFreeUser({ backupMoviesForFreeUser: recommendedMovies }));
    } else {
      const currentUser = yield select(state => state.auth.currentUser);
      yield put(recommendedMoviesSuccess({
        recommendedMovies, offset, next, prev, total, currentUser,
      }));
    }
  } catch (error) {
    if (!isLoadBackupMovies) {
      yield put(recommendedMoviesFail({ error }));
    }
  }
}

export default function* recommendationsSaga() {
  yield takeEvery(FETCH_RECOMMENDED_MOVIES_REQUEST, fetchRecommendedMovies);
}
