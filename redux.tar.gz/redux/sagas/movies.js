import { call, select, put, take, takeEvery } from 'redux-saga/effects';
import Promise from 'bluebird';
import {
  requestFinishOnboarding,
  requestRateMovie,
  requestSkipMovie,
  requestUndoMovie,
} from '../../services/movies';

import {
  activateLoader,
  createMovieProfile,
} from './auth';

import {
  FINISH_ONBOARDING_REQUEST,
  FINISH_ONBOARDING_SUCCESS,
  FINISH_ONBOARDING_FAIL,
  RATE_MOVIE_REQUEST,
  RATE_MOVIE_SUCCESS,
  RATE_MOVIE_FAIL,
  SKIP_MOVIE_REQUEST,
  SKIP_MOVIE_SUCCESS,
  SKIP_MOVIE_FAIL,
  UNDO_MOVIE_REQUEST,
  UNDO_MOVIE_SUCCESS,
  UNDO_MOVIE_FAIL,
  HAS_ONBOARDING_AFTER_EFFECTS_COMPLETED,

} from '../constants';


function finishOnboardingSuccess(payload) {
  return { type: FINISH_ONBOARDING_SUCCESS, payload };
}

function finishOnboardingFail(payload) {
  return { type: FINISH_ONBOARDING_FAIL, payload };
}

function* finishOnboarding({ requestPayload }) {
  const url = 'movies/onboard';
  try {
    const status = yield call(requestFinishOnboarding, { url, requestPayload });

    // eslint-disable-next-line no-underscore-dangle
    const onboardingStatus = status._bodyText;
    yield put(finishOnboardingSuccess({ onboardingStatus }));
  } catch (error) {
    yield put(finishOnboardingFail({ error }));
  }
}

function wait() {
  return Promise.delay(2000);
}

/* used for API calls that needs to happen imediatly after successful onboarding */
function* completeOnboardingAfterEffects() {
  yield take(FINISH_ONBOARDING_SUCCESS);
  while (true) {
    yield call(wait);
    try {
      yield call(createMovieProfile);
      const movieProfile = yield select(state => state.auth.currentUser.movieProfile);
      if (movieProfile.matchesReady) {
        yield put({ type: HAS_ONBOARDING_AFTER_EFFECTS_COMPLETED });
        break;
      }
      // yield put({ type: HAS_ONBOARDING_AFTER_EFFECTS_COMPLETED });
    } catch (e) {
      // yield put({ type: HAS_ONBOARDING_AFTER_EFFECTS_COMPLETED });
    }
  }
}

function rateMovieSuccess(payload) {
  return { type: RATE_MOVIE_SUCCESS, payload };
}

function rateMovieFail(payload) {
  return { type: RATE_MOVIE_FAIL, payload };
}

function* rateMovieRequest({ requestPayload }) {
  const { slug, rating } = requestPayload;
  const url = `movies/${slug}/rating`;
  yield put(activateLoader());

  const movieRated = yield call(requestRateMovie, { url, requestPayload: { rating } });
  // eslint-disable-next-line no-underscore-dangle
  const ratedMovieResponse = JSON.parse(movieRated._bodyInit).profile;
  try {
    yield put(rateMovieSuccess({ ratedMovieResponse }));
  } catch (error) {
    yield put(rateMovieFail({ error }));
  }
}

function skipMovieSuccess(payload) {
  return { type: SKIP_MOVIE_SUCCESS, payload };
}

function skipMovieFail(payload) {
  return { type: SKIP_MOVIE_FAIL, payload };
}

function* skipMovieRequest({ requestPayload }) {
  const url = `movies/${requestPayload}/skip`;
  try {
    yield put(activateLoader());
    const movieSkipped = yield call(requestSkipMovie, { url });

    // eslint-disable-next-line no-underscore-dangle
    const skippedMovieResponse = JSON.parse(movieSkipped._bodyInit).profile;

    yield put(skipMovieSuccess({ skippedMovieResponse }));
  } catch (error) {
    yield put(skipMovieFail({ error }));
  }
}

function undoMovieSuccess(payload) {
  return { type: UNDO_MOVIE_SUCCESS, payload };
}

function undoMovieFail(payload) {
  return { type: UNDO_MOVIE_FAIL, payload };
}

function* undoMovieRequest({ requestPayload }) {
  const url = `movies/${requestPayload}/rating`;
  try {
    const undoMovie = yield call(requestUndoMovie, { url });

    // eslint-disable-next-line no-underscore-dangle
    const undoMovieResponse = JSON.parse(undoMovie._bodyInit).profile;
    yield put(undoMovieSuccess({ undoMovieResponse }));
  } catch (error) {
    yield put(undoMovieFail({ error }));
  }
}

export default function* movies() {
  yield takeEvery(FINISH_ONBOARDING_REQUEST, finishOnboarding);
  yield takeEvery(FINISH_ONBOARDING_REQUEST, completeOnboardingAfterEffects);
  yield takeEvery(RATE_MOVIE_REQUEST, rateMovieRequest);
  yield takeEvery(SKIP_MOVIE_REQUEST, skipMovieRequest);
  yield takeEvery(UNDO_MOVIE_REQUEST, undoMovieRequest);
}
