import _ from 'lodash';

// TODO will use re-reselect for the selector purposes
const getMovies = state => state.recommendations.movies;
const getMoviesToDisplay = state => state.recommendations.moviesToDisplay;
const getRecommendedMoviesOffset = state => state.recommendations.offset;
const isRequestInProgress = state => state.recommendations.isLoading;
const getMoviesForTaste = state => state.taste.moviesForTaste;
const isMoviesForTasteRequestInProgress = state => state.taste.isLoading;
const getMoviesNotYetDisplayed = (state) => {
  const { movies, moviesToDisplay, moviesNotToDisplay } = state.recommendations;
  const tmp = _.differenceBy(movies, moviesToDisplay, 'slug');
  return _.differenceBy(tmp, moviesNotToDisplay, 'slug');
};

export {
  getMovies,
  getMoviesToDisplay,
  getMoviesNotYetDisplayed,
  getRecommendedMoviesOffset,
  isRequestInProgress,
  getMoviesForTaste,
  isMoviesForTasteRequestInProgress,
};
