/* TODOS
  - @TODO create a `LocalData` dir and move all the AsyncStorage stuff there.
  - @TODO Move all the initial States to the global file `InitialStates`
  and make a switch among all the reducers.
*/

import { AsyncStorage } from 'react-native';
import { isUndefined } from 'lodash';
import User from '../../services/User';
import {
  // Successes (Alphabetical)
  CREATE_MOVIE_PROFILE_SUCCESS,
  FETCH_USER_INFO_SUCCESS,
  FINISH_ONBOARDING_SUCCESS,
  GUEST_AUTH_SUCCESS,
  LOCAL_SIGNIN_SUCCESS,
  RATE_MOVIE_SUCCESS,
  SKIP_MOVIE_SUCCESS,
  UNDO_MOVIE_SUCCESS,
  UPDATE_USER_EMAIL_SUCCESS,
  UPDATE_USERNAME_SUCCESS,

  // Failures (Alphabetical)
  CREATE_MOVIE_PROFILE_FAIL,
  FETCH_USER_INFO_FAIL,
  GUEST_AUTH_FAIL,
  LOCAL_SIGNIN_FAIL,
  RATE_MOVIE_FAIL,
  SKIP_MOVIE_FAIL,
  UNDO_MOVIE_FAIL,

  // Miscellaneous (Alphabetical)
  ACTIVATE_AUTH_LOADER,
  SET_USER_TOKEN,
  LOGIN_AFTER_EFFECTS_COMPLETED,
  SIGN_OUT,
  UPDATE_USER_SUBSCRIPTION,
  UPDATE_USER_MOVIE_PROFILE,
  UPDATE_USER_PROFILE_SUCCESS,
} from '../constants';

const INITIAL_AUTH_STATE = {
  currentUser: {
    movieProfile: {},
    profile: {},
    token: {},
  },
  error: null,
  errorMessages: {},
  loadingRequest: false,
  hasLoginAfterEffectsCompleted: false,
};

export default function (userData = INITIAL_AUTH_STATE, action) {
  const {
    currentUser,
    error,
    errorMessages,
    loadingRequest,
    hasLoginAfterEffectsCompleted,

  } = INITIAL_AUTH_STATE;

  switch (action.type) {
    // Successes

    case CREATE_MOVIE_PROFILE_SUCCESS:
      AsyncStorage.setItem('currentUserMovieProfile', JSON.stringify(action.payload.userMovieProfile));
      return {
        ...userData,
        currentUser: {
          ...userData.currentUser,
          movieProfile: action.payload.userMovieProfile,
        },
        error,
        errorMessages,
        loadingRequest,
      };

    case FETCH_USER_INFO_SUCCESS:
      AsyncStorage.setItem('currentUser', JSON.stringify(action.payload.newGuest));
      return {
        ...userData,
        currentUser: {
          ...userData.currentUser,
          profile: action.payload.newGuest,
        },
        error,
        errorMessages,
        loadingRequest,
      };

    case UPDATE_USER_PROFILE_SUCCESS:
      AsyncStorage.setItem('currentUser', JSON.stringify(action.payload.data));
      return {
        ...userData,
        currentUser: {
          ...userData.currentUser,
          profile: action.payload.data,
        },
        error,
        errorMessages,
        loadingRequest,
      };

    case FINISH_ONBOARDING_SUCCESS:
      return {
        ...userData,
        error,
        errorMessages,
        loadingRequest,
      };

    case UPDATE_USER_EMAIL_SUCCESS: {
      const user = { ...userData.currentUser };
      user.profile.email = action.payload.email;
      AsyncStorage.setItem('currentUser', JSON.stringify(user.profile));
      return {
        ...userData,
        currentUser: user,
        error,
        errorMessages,
        loadingRequest,
      };
    }

    case UPDATE_USERNAME_SUCCESS: {
      const user = { ...userData.currentUser };
      user.profile.username = action.payload.username;
      AsyncStorage.setItem('currentUser', JSON.stringify(user.profile));
      return {
        ...userData,
        currentUser: user,
        error,
        errorMessages,
        loadingRequest,
      };
    }

    case UPDATE_USER_SUBSCRIPTION: {
      const user = { ...userData.currentUser };
      user.profile.premium = action.payload.plan;
      AsyncStorage.setItem('currentUser', JSON.stringify(user.profile));
      return {
        ...userData,
        currentUser: user,
        error,
        errorMessages,
        loadingRequest,
      };
    }

    case UPDATE_USER_MOVIE_PROFILE: {
      const newMovieProfile = {
        ...userData.currentUser.movieProfile,
        ...action.payload,
      };
      AsyncStorage.setItem('currentUserMovieProfile', JSON.stringify(newMovieProfile));
      return {
        ...userData,
        currentUser: {
          ...userData.currentUser,
          movieProfile: newMovieProfile,
        },
        error,
        errorMessages,
        loadingRequest,
      };
    }

    case GUEST_AUTH_SUCCESS:
      AsyncStorage.setItem('userToken', JSON.stringify(action.payload.guestToken));
      User.setUserToken(action.payload.guestToken.token);
      return {
        ...userData,
        currentUser: {
          ...userData.currentUser,
          token: action.payload.guestToken,
        },
        error,
        errorMessages,
        loadingRequest,
      };

    case LOCAL_SIGNIN_SUCCESS:
      if (action.payload.error) {
        return {
          ...userData,
          currentUser: {
            ...userData.currentUser,
            movieProfile: {},
            profile: {},
            token: {},
          },
          error: true,
          errorMessages: action.payload.message,
          loadingRequest,
        };
      }
      AsyncStorage.setItem('userToken', JSON.stringify(action.payload.data));
      User.setUserToken(action.payload.data.token);
      return {
        ...userData,
        currentUser: {
          ...userData.currentUser,
          token: action.payload.data,
        },
        error,
        errorMessages,
        loadingRequest,
      };

    case RATE_MOVIE_SUCCESS: {
      const {
        ratedMovieResponse: {
          strength,
          ratings,
          rank,
          level,
        },
      } = action.payload;

      let updatedMovieProfile = {
        ...userData.currentUser.movieProfile,
        ratings,
        strength,
      };

      if (!isUndefined(rank)) {
        updatedMovieProfile = {
          ...updatedMovieProfile,
          rank,
        };
      }

      if (!isUndefined(level)) {
        updatedMovieProfile = {
          ...updatedMovieProfile,
          level,
        };
      }

      AsyncStorage.mergeItem('currentUserMovieProfile', JSON.stringify(updatedMovieProfile));

      return {
        ...userData,
        currentUser: {
          ...userData.currentUser,
          movieProfile: updatedMovieProfile,
        },
        error,
        errorMessages,
        loadingRequest,
      };
    }

    case SKIP_MOVIE_SUCCESS: {
      const { skippedMovieResponse: { strength, rank, level } } = action.payload;
      let updatedMovieProfile = {
        ...userData.currentUser.movieProfile,
        strength,
      };

      if (!isUndefined(rank)) {
        updatedMovieProfile = {
          ...updatedMovieProfile,
          rank,
        };
      }

      if (!isUndefined(level)) {
        updatedMovieProfile = {
          ...updatedMovieProfile,
          level,
        };
      }

      AsyncStorage.mergeItem('currentUserMovieProfile', JSON.stringify(updatedMovieProfile));

      return {
        ...userData,
        currentUser: {
          ...userData.currentUser,
          movieProfile: updatedMovieProfile,
        },
        error,
        errorMessages,
        loadingRequest,
      };
    }

    case UNDO_MOVIE_SUCCESS: {
      const {
        undoMovieResponse: {
          strength,
          ratings,
          rank,
          level,
        },
      } = action.payload;

      let updatedMovieProfile = {
        ...userData.currentUser.movieProfile,
        strength,
        ratings,
      };

      if (!isUndefined(rank)) {
        updatedMovieProfile = {
          ...updatedMovieProfile,
          rank,
        };
      }

      if (!isUndefined(level)) {
        updatedMovieProfile = {
          ...updatedMovieProfile,
          level,
        };
      }

      AsyncStorage.mergeItem('currentUserMovieProfile', JSON.stringify(updatedMovieProfile));

      return {
        ...userData,
        currentUser: {
          ...userData.currentUser,
          movieProfile: updatedMovieProfile,
        },
        error,
        errorMessages,
        loadingRequest,
      };
    }

    // Failures

    case CREATE_MOVIE_PROFILE_FAIL:
      return {
        ...userData,
        error: true,
        errorMessages: action.payload.error,
        loadingRequest,
      };

    case FETCH_USER_INFO_FAIL:
      return {
        ...userData,
        error: true,
        errorMessages: action.payload.error,
        loadingRequest,
      };

    case GUEST_AUTH_FAIL:
      return {
        ...userData,
        error: true,
        errorMessages: action.payload.error,
        loadingRequest,
      };

    case LOCAL_SIGNIN_FAIL:
      return {
        ...userData,
        error: true,
        errorMessages: action.payload.error,
        loadingRequest,
      };

    case RATE_MOVIE_FAIL:
      return {
        ...userData,
        error: true,
        errorMessages: action.payload.error,
        loadingRequest,
      };

    case SKIP_MOVIE_FAIL:
      return {
        ...userData,
        error: true,
        errorMessages: action.payload.error,
        loadingRequest,
      };

    case UNDO_MOVIE_FAIL:
      return {
        ...userData,
        error: true,
        errorMessages: action.payload.error,
        loadingRequest,
      };

    // Miscellaneous
    case ACTIVATE_AUTH_LOADER:
      return {
        ...userData,
        error,
        errorMessages,
        loadingRequest: true,
      };

    case SET_USER_TOKEN:
      return {
        ...userData,
        currentUser: {
          ...userData.currentUser,
          token: action.payload,
        },
        error,
        errorMessages,
        loadingRequest,
      };
    case LOGIN_AFTER_EFFECTS_COMPLETED:
      return {
        ...userData,
        hasLoginAfterEffectsCompleted: true,
      };
    case SIGN_OUT:
      AsyncStorage.removeItem('userToken');
      AsyncStorage.removeItem('currentUser');
      AsyncStorage.removeItem('currentUserMovieProfile');
      return {
        ...userData,
        currentUser,
        error,
        errorMessages,
        loadingRequest,
        hasLoginAfterEffectsCompleted,
      };
    default:
      return {
        ...userData,
        loadingRequest,
      };
  }
}
