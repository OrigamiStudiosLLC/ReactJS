/* eslint no-plusplus: ["error", { "allowForLoopAfterthoughts": true }] */
import _ from 'lodash';
import {
  FETCH_RECOMMENDED_MOVIES_SUCCESS,
  FETCH_RECOMMENDED_MOVIES_FAIL,
  ACTIVATE_LOADER,
  FETCH_RECOMMENDED_MOVIES_REPLACE_MOVIE,
  FETCH_RECOMMENDED_MOVIES_CLEAN,
  UPDATE_BACKUP_RECOMMENDED_MOVIES_FOR_FREE_USER,
} from '../constants';

function isSubscriptionActive(currentUser) {
  if (!_.isEmpty(currentUser) &&
    currentUser.profile.premium &&
    currentUser.profile.premium.active) {
    return true;
  }

  return false;
}

const initialState = {
  movies: [],
  moviesToDisplay: [],
  moviesNotToDisplay: [],
  backupMoviesForFreeUser: [],
  isLoading: false,
  error: '',
  offset: 0,
};

export default function (state = initialState, action) {
  switch (action.type) {
    case FETCH_RECOMMENDED_MOVIES_SUCCESS:
    {
      const {
        offset, next, prev, total, recommendedMovies, currentUser,
      } = action.payload;

      const newState = {
        ...state,
        movies: recommendedMovies,
        moviesToDisplay: [...recommendedMovies],
        moviesNotToDisplay: [],
        backupMoviesForFreeUser: [],
        offset,
        next,
        prev,
        total,
        isLoading: false,
      };

      if (!isSubscriptionActive(currentUser) && newState.movies.length > 18) {
        newState.moviesToDisplay = newState.movies.slice(0, newState.movies.length - 6);
      }

      if (offset) {
        newState.movies = [...state.movies, ...recommendedMovies];
        newState.moviesToDisplay = [...state.moviesToDisplay, ...recommendedMovies];
        if (!isSubscriptionActive(currentUser)
        && (newState.movies.length - state.movies.length) > 15) {
          newState.moviesToDisplay = newState.moviesToDisplay.slice(
            0,
            newState.moviesToDisplay.length - 6,
          );
        }
      }
      return newState;
    }
    case FETCH_RECOMMENDED_MOVIES_FAIL:
      return {
        ...state,
        isLoading: false,
        error: action.payload.error,
      };
    case ACTIVATE_LOADER:
      return {
        ...state,
        isLoading: true,
      };
    case UPDATE_BACKUP_RECOMMENDED_MOVIES_FOR_FREE_USER:
    {
      let { backupMoviesForFreeUser } = action.payload;
      backupMoviesForFreeUser = _.differenceBy(backupMoviesForFreeUser, state.movies, 'slug');
      return {
        ...state,
        movies: [...state.movies, ...backupMoviesForFreeUser],
        backupMoviesForFreeUser,
      };
    }
    case FETCH_RECOMMENDED_MOVIES_CLEAN:
      return {
        ...initialState,
      };
    case FETCH_RECOMMENDED_MOVIES_REPLACE_MOVIE:
    {
      const tmp = _.differenceBy(state.movies, state.moviesToDisplay, 'slug');
      const moviesNotYetDisplayed = _.differenceBy(tmp, state.moviesNotToDisplay, 'slug');
      const indexAtWhichToReplace = _.findIndex(state.moviesToDisplay, ['slug', action.payload.movieSlug]);

      if (indexAtWhichToReplace !== -1) {
        const moviesToDisplay = [...state.moviesToDisplay];
        const movieToHide = moviesToDisplay[indexAtWhichToReplace];

        if (moviesNotYetDisplayed.length) {
          const [movieItem] = moviesNotYetDisplayed;
          moviesToDisplay[indexAtWhichToReplace] = movieItem;
          return {
            ...state,
            moviesToDisplay,
            moviesNotToDisplay: [...state.moviesNotToDisplay, movieToHide],
          };
        }

        moviesToDisplay.splice(indexAtWhichToReplace, 1);
        return {
          ...state,
          moviesToDisplay,
          moviesNotToDisplay: [...state.moviesNotToDisplay, movieToHide],
        };
      }


      return {
        ...state,
      };
    }
    default:
      return state;
  }
}
