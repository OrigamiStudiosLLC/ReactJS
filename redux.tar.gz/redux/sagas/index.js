import { all } from 'redux-saga/effects';
import authSaga from './auth';
import recommendationsSaga from './recommendations';
import watchListSaga from './watchList';
import seenMoviesSaga from './seenMovies';
import tasteSaga from './taste';
import movies from './movies';
import subscription from './subscription';
import startTrial from './startTrial';
import updateNetflixRegion from './updateNetflixRegion';
import updateEmail from './updateEmail';
import updateUsername from './updateUsername';
import verifyInAppPurchase from './verifyInAppPurchase';
import searchInput from './Search';

import updateUserProfile from './updateUserProfile';

export default function* rootSaga() {
  yield all([
    searchInput(),
    authSaga(),
    recommendationsSaga(),
    watchListSaga(),
    seenMoviesSaga(),
    tasteSaga(),
    movies(),
    subscription(),
    startTrial(),
    updateNetflixRegion(),
    updateEmail(),
    updateUsername(),
    verifyInAppPurchase(),
    updateUserProfile(),
  ]);
}
