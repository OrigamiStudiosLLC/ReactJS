import {
  VERIFY_IN_APP_PURCHASE_REQUEST,
  VERIFY_IN_APP_PURCHASE_INPROGRESS,
} from '../constants';

function verifyInAppPurchaseRequest(requestPayload) {
  return {
    type: VERIFY_IN_APP_PURCHASE_REQUEST,
    requestPayload,
  };
}

function loaderIndicator() {
  return { type: VERIFY_IN_APP_PURCHASE_INPROGRESS };
}

export default function verifyInAppPurchase(requestPayload = {}) {
  return (dispatch) => {
    dispatch(verifyInAppPurchaseRequest(requestPayload));
    dispatch(loaderIndicator());
  };
}
