// Need to replace the selectors with the reselect or if find some time then re-reselect
const getCurrentUser = state => state.auth.currentUser;
const getRequestStatus = state => state.auth.loadingRequest;

export {
  getCurrentUser,
  getRequestStatus,
};
