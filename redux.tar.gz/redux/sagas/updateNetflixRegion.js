/* eslint no-underscore-dangle: 0 */
import { call, put, takeEvery } from 'redux-saga/effects';
import { isJson } from '../../Utils';
import { requestUpdateNetflixRegion } from '../../services/updateNetflixRegion';
import {
  UPDATE_NETFLIX_REGION_REQUEST,
  UPDATE_NETFLIX_REGION_SUCCESS,
  UPDATE_NETFLIX_REGION_FAIL,
  UPDATE_USER_MOVIE_PROFILE,
} from '../constants';

function updateUserMovieProfile(payload) {
  return { type: UPDATE_USER_MOVIE_PROFILE, payload };
}

function updateNetflixRegionSuccess(payload) {
  return { type: UPDATE_NETFLIX_REGION_SUCCESS, payload };
}

function updateNetflixRegionFail(payload) {
  return { type: UPDATE_NETFLIX_REGION_FAIL, payload };
}

function* updateNetflixRegion(aPayload) {
  const { requestPayload } = aPayload;
  const url = 'me/region';

  try {
    const resBody = yield call(requestUpdateNetflixRegion, { url, requestPayload });

    let responseData;

    if (isJson(resBody._bodyText)) {
      responseData = JSON.parse(resBody._bodyText);
    } else {
      responseData = { message: resBody._bodyText };
    }

    let payload;

    if (!resBody.ok) {
      payload = {
        error: responseData,
      };
      yield put(updateNetflixRegionFail(payload));
    } else {
      payload = {
        data: responseData,
      };
      if (resBody.status === 201) {
        yield put(updateUserMovieProfile({ region: requestPayload.region }));
      }
      yield put(updateNetflixRegionSuccess(payload));
    }
  } catch (error) {
    yield put(updateNetflixRegionFail({ error }));
  }
}

export default function* updateNetflixRegionSaga() {
  yield takeEvery(UPDATE_NETFLIX_REGION_REQUEST, updateNetflixRegion);
}
