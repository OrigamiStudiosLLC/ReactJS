import {
  UPDATE_USERNAME_REQUEST,
  UPDATE_USERNAME_INPROGRESS,
} from '../constants';

function updateUsernameRequest(requestPayload) {
  return {
    type: UPDATE_USERNAME_REQUEST,
    requestPayload,
  };
}

export default function updateUsername(requestPayload = {}) {
  return (dispatch) => {
    dispatch(updateUsernameRequest(requestPayload));
    dispatch({ type: UPDATE_USERNAME_INPROGRESS });
  };
}
