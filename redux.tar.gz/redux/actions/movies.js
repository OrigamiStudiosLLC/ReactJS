import {
  FINISH_ONBOARDING_REQUEST,
  RATE_MOVIE_REQUEST,
  SKIP_MOVIE_REQUEST,
  UNDO_MOVIE_REQUEST,
} from '../constants';

import {
  requestDismissMovie,
} from '../../services/movies';

function finishOnboardingRequest(requestPayload) {
  return { type: FINISH_ONBOARDING_REQUEST, requestPayload };
}

function rateMovieRequest(requestPayload) {
  return { type: RATE_MOVIE_REQUEST, requestPayload };
}

function skipMovieRequest(requestPayload) {
  return { type: SKIP_MOVIE_REQUEST, requestPayload };
}

function undoMovieRequest(requestPayload) {
  return { type: UNDO_MOVIE_REQUEST, requestPayload };
}

function finishOnboarding(requestPayload) {
  return dispatch => dispatch(finishOnboardingRequest(requestPayload));
}

function rateMovie(requestPayload) {
  return dispatch => dispatch(rateMovieRequest(requestPayload));
}

function skipMovie(requestPayload) {
  return dispatch => dispatch(skipMovieRequest(requestPayload));
}

function undoCurrentMovie(requestPayload) {
  return dispatch => dispatch(undoMovieRequest(requestPayload));
}

export function dismissMovie(movieSlug) {
  return () => {
    const url = `movies/${movieSlug}/dismiss`;
    return requestDismissMovie({ url });
  };
}

export {
  finishOnboarding,
  finishOnboardingRequest,
  rateMovie,
  skipMovie,
  undoCurrentMovie,
};
