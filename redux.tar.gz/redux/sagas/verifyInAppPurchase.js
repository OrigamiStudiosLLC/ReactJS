/* eslint no-underscore-dangle: 0 */
import { call, put, takeEvery } from 'redux-saga/effects';
import { isJson } from '../../Utils';
import { requestVerifyInAppPurchase } from '../../services/subscription';
import {
  VERIFY_IN_APP_PURCHASE_REQUEST,
  VERIFY_IN_APP_PURCHASE_SUCCESS,
  VERIFY_IN_APP_PURCHASE_FAIL,
  UPDATE_USER_SUBSCRIPTION,
} from '../constants';

function updateUserSubscriptionPlan(payload) {
  return { type: UPDATE_USER_SUBSCRIPTION, payload };
}

function verifyInAppPurchaseSuccess(payload) {
  return { type: VERIFY_IN_APP_PURCHASE_SUCCESS, payload };
}

function verifyInAppPurchaseFail(payload) {
  return { type: VERIFY_IN_APP_PURCHASE_FAIL, payload };
}

function* verifyInAppPurchase(aPayload) {
  const { requestPayload } = aPayload;
  const url = 'premium/iap/ios';

  try {
    const resBody = yield call(requestVerifyInAppPurchase, { url, requestPayload });
    console.warn(`Apple-Receipt=${requestPayload.receipt}`);
    console.warn(`Verify-Receipt-Resp=${resBody._bodyText}`);
    let responseData;

    if (isJson(resBody._bodyText)) {
      responseData = JSON.parse(resBody._bodyText);
    } else {
      responseData = { message: resBody._bodyText };
    }

    let payload;

    if (!resBody.ok) {
      payload = {
        error: responseData,
      };
      yield put(verifyInAppPurchaseFail(payload));
    } else {
      payload = {
        data: responseData,
      };
      yield put(verifyInAppPurchaseSuccess(payload));
      if (responseData.plan) {
        yield put(updateUserSubscriptionPlan({ plan: responseData }));
      }
    }
  } catch (error) {
    yield put(verifyInAppPurchaseFail({ error }));
  }
}

export default function* verifyInAppPurchaseSaga() {
  yield takeEvery(VERIFY_IN_APP_PURCHASE_REQUEST, verifyInAppPurchase);
}
