// import { AsyncStorage } from 'react-native';
import { combineReducers } from 'redux';
import signup from './signup';
import auth from './auth';
import nav from './nav';
import recommendations from './recommendations';
import watchList from './watchList';
import seenMovies from './seenMovies';
import taste from './taste';
import navBar from './navBar';
import editPassword from './editPassword';
import subscription from './subscription';
import startTrial from './startTrial';
import updateNetflixRegion from './updateNetflixRegion';
import updateEmail from './updateEmail';
import updateUsername from './updateUsername';
import updateUserProfile from './updateUserProfile';
import globalFlags from './globalFlags';
import searchInput from './Search';

import verifyInAppPurchase from './verifyInAppPurchase';

// AsyncStorage.clear();

const rootReducer = {
  signup,
  searchInput,
  auth,
  nav,
  recommendations,
  watchList,
  seenMovies,
  taste,
  navBar,
  editPassword,
  subscription,
  startTrial,
  updateNetflixRegion,
  updateEmail,
  updateUsername,
  updateUserProfile,
  globalFlags,
  verifyInAppPurchase,
};

export default combineReducers(rootReducer);
