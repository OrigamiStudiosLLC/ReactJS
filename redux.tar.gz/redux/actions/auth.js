/**
 * TODOS:
 * Move all the action creators to some global file where all the action creators will be placed.
 */
import {
  GUEST_AUTH_REQUEST,
  CREATE_GUEST_USER_REQUEST,

  FETCH_USER_INFO_REQUEST,
  FETCH_USER_INFO_SUCCESS,
  CREATE_MOVIE_PROFILE_REQUEST,

  CREATE_MOVIE_PROFILE_SUCCESS,

  LOCAL_SIGNIN_REQUEST,

  SET_USER_TOKEN,

  FACEBOOK_SIGNIN_REQUEST,
  SIGNUP_REQUEST,
  EDIT_PASSWORD_REQUEST,
  SIGN_OUT,
} from '../constants';

function createRequestGuestAuth() {
  return { type: GUEST_AUTH_REQUEST };
}

function createGuestUserRequest() {
  return { type: CREATE_GUEST_USER_REQUEST };
}

function fetchUserInfoRequest() {
  return { type: FETCH_USER_INFO_REQUEST };
}

function createMovieProfileRequest() {
  return { type: CREATE_MOVIE_PROFILE_REQUEST };
}

function createLocalSignInRequest(requestPayload) {
  return { type: LOCAL_SIGNIN_REQUEST, requestPayload };
}

function requestUserTokenSet(payload) {
  return { type: SET_USER_TOKEN, payload };
}

export function requestFacebookSignIn(requestPayload) {
  return { type: FACEBOOK_SIGNIN_REQUEST, requestPayload };
}

export function requestGuestAuth() {
  return dispatch => dispatch(createRequestGuestAuth());
}

export function createGuestUser() {
  return dispatch => dispatch(createGuestUserRequest());
}

export function fetchUserInfo() {
  return dispatch => dispatch(fetchUserInfoRequest());
}

export function createMovieProfile() {
  return dispatch => dispatch(createMovieProfileRequest());
}

export function requestLocalSignIn(requestPayload) {
  return dispatch => dispatch(createLocalSignInRequest(requestPayload));
}

export function dispatchToken(token) {
  return dispatch => dispatch(requestUserTokenSet(token));
}

export function dispatchCurrentUser(payload) {
  return dispatch => dispatch({ type: FETCH_USER_INFO_SUCCESS, payload });
}

export function dispatchCurrentUserMovieProfile(payload) {
  return dispatch => dispatch({ type: CREATE_MOVIE_PROFILE_SUCCESS, payload });
}

export function signup(requestPayload) {
  return { type: SIGNUP_REQUEST, requestPayload };
}

export function editPassword(requestPayload) {
  return { type: EDIT_PASSWORD_REQUEST, requestPayload };
}

export function signout() {
  return { type: SIGN_OUT };
}
