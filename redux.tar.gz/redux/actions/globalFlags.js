import {
  SET_USER_NEW_SIGN_UP,
  CLEAR_USER_NEW_SIGN_UP,
} from '../constants';

export function setUserNewSignUp() {
  return {
    type: SET_USER_NEW_SIGN_UP,
  };
}

export function clearUserNewSignUp() {
  return {
    type: CLEAR_USER_NEW_SIGN_UP,
  };
}
