import {
  UPDATE_USER_EMAIL_REQUEST,
  UPDATE_USER_EMAIL_INPROGRESS,
} from '../constants';

function updateUserEmailRequest(requestPayload) {
  return {
    type: UPDATE_USER_EMAIL_REQUEST,
    requestPayload,
  };
}

export default function updateUserEmail(requestPayload = {}) {
  return (dispatch) => {
    dispatch(updateUserEmailRequest(requestPayload));
    dispatch({ type: UPDATE_USER_EMAIL_INPROGRESS });
  };
}
