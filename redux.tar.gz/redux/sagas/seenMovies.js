import { call, put, takeEvery } from 'redux-saga/effects';
import { fetchSeenMovies } from '../../services/seenMovies';
import {
  FETCH_SEEN_MOVIES_REQUEST,
  FETCH_SEEN_MOVIES_SUCCESS,
  FETCH_SEEN_MOVIES_FAIL,

} from '../constants';

function fetchSeenMoviesSuccess(payload) {
  return { type: FETCH_SEEN_MOVIES_SUCCESS, payload };
}

function fetchSeenMoviesFail(payload) {
  return { type: FETCH_SEEN_MOVIES_FAIL, payload };
}

function* fetchSeenMoviesRequest(payload) {
  const { username, offset = 0, rating = null } = payload.requestPayload;
  const url = `users/${username}/ratings`;
  const queryString = {
    offset,
  };
  if (rating) queryString.rating = rating;

  const resBody = yield call(fetchSeenMovies, { url, queryString });

  try {
    const {
      movies, next, prev, total,
    } = JSON.parse(resBody._bodyText); // eslint-disable-line no-underscore-dangle
    yield put(fetchSeenMoviesSuccess({
      movies, offset, next, prev, total,
    }));
  } catch (error) {
    yield put(fetchSeenMoviesFail({ error }));
  }
}

export default function* seenSaga() {
  yield takeEvery(FETCH_SEEN_MOVIES_REQUEST, fetchSeenMoviesRequest);
}
