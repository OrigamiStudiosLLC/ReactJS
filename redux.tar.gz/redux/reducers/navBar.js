import {
  SHOW_NAVIGATION_BAR,
  HIDE_NAVIGATION_BAR,
  NORMALIZE_NAVIGATION_BAR_TO_DEFAULT_STATE,
  SELECT_TAB_BAR,
} from '../constants';

const initialState = {
  isNavBarHidden: true,
  isNavBarInDefaultState: false,
  tabBarSelectedState: 0,
};

export default function (state = initialState, action) {
  switch (action.type) {
    case SHOW_NAVIGATION_BAR:
      return {
        ...state,
        isNavBarHidden: false,
      };
    case HIDE_NAVIGATION_BAR:
      return {
        ...state,
        isNavBarHidden: true,
      };
    case NORMALIZE_NAVIGATION_BAR_TO_DEFAULT_STATE:
      return {
        ...state,
        isNavBarInDefaultState: true,
      };
    case SELECT_TAB_BAR:
      return {
        ...state,
        tabBarSelectedState: action.payload.tabNum,
      };
    default:
      return state;
  }
}
