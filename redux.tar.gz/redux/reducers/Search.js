import {
    FETCH_RESULT_REQUEST,
    FETCH_RESULT_SUCCESS,
    FETCH_RESULT_FAIL,
} from '../constants';


const initialState = {
    data: false,
};

export default function (state = initialState, action) {
    switch (action.type) {
        case FETCH_RESULT_REQUEST:
            return {
                ...state,
            };
        case FETCH_RESULT_SUCCESS:
            return {
                ...state,

            };
        case FETCH_RESULT_FAIL:
            return {
                ...state,

            };
        default:
            return state;
    }
}

