import {
  SHOW_NAVIGATION_BAR,
  HIDE_NAVIGATION_BAR,
  NORMALIZE_NAVIGATION_BAR_TO_DEFAULT_STATE,
  SELECT_TAB_BAR,
} from '../constants';

export function showNavigationBar() {
  return {
    type: SHOW_NAVIGATION_BAR,
  };
}

export function hideNavigationBar() {
  return {
    type: HIDE_NAVIGATION_BAR,
  };
}

export function normalizeNavigationBar() {
  return {
    type: NORMALIZE_NAVIGATION_BAR_TO_DEFAULT_STATE,
  };
}

export function selectTabBar(payload) {
  return {
    type: SELECT_TAB_BAR,
    payload,
  };
}
