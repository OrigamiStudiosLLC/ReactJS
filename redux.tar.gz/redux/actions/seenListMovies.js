import {
  FETCH_SEEN_MOVIES_REQUEST,
  FETCH_SEEN_MOVIES_LOADING,
  FETCH_SEEN_MOVIES_CLEAR,
} from '../constants';

function fetchMoviesRequest(requestPayload) {
  return {
    type: FETCH_SEEN_MOVIES_REQUEST,
    requestPayload,
  };
}

function loaderIndicator() {
  return { type: FETCH_SEEN_MOVIES_LOADING };
}

export function clearSeenListMovies() {
  return { type: FETCH_SEEN_MOVIES_CLEAR };
}

export function fetchSeenMovies(requestPayload = {}) {
  return (dispatch) => {
    dispatch(fetchMoviesRequest(requestPayload));
    dispatch(loaderIndicator());
  };
}
