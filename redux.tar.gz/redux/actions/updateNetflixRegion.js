import {
  UPDATE_NETFLIX_REGION_REQUEST,
  UPDATE_NETFLIX_REGION_INPROGRESS,
} from '../constants';

function updateNetflixRegionRequest(requestPayload) {
  return {
    type: UPDATE_NETFLIX_REGION_REQUEST,
    requestPayload,
  };
}

export default function updateNetflixRegion(requestPayload = {}) {
  return (dispatch) => {
    dispatch(updateNetflixRegionRequest(requestPayload));
    dispatch({ type: UPDATE_NETFLIX_REGION_INPROGRESS });
  };
}
