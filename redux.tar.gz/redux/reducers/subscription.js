import {
  FETCH_SUBSCRIPTION_SUCCESS,
  FETCH_SUBSCRIPTION_FAIL,
  FETCH_SUBSCRIPTION_LOADING,
} from '../constants';

const initialState = {
  subscription: null,
  isLoading: false,
  error: null,
};

export default function (state = initialState, action) {
  switch (action.type) {
    case FETCH_SUBSCRIPTION_SUCCESS:
    {
      const newState = {
        ...state,
        subscription: action.payload.data,
        isLoading: false,
        error: null,
      };

      return newState;
    }
    case FETCH_SUBSCRIPTION_FAIL:
      return {
        ...state,
        isLoading: false,
        error: action.payload.error,
      };
    case FETCH_SUBSCRIPTION_LOADING:
      return {
        ...state,
        isLoading: true,
      };
    default:
      return state;
  }
}
