import {
  SIGNUP_SUCCESS,
  SIGNUP_FAIL,
  SIGNUP_INPROGRESS,
} from '../constants';

const initialState = {
  data: null,
  isLoading: false,
  error: null,
};

export default function (state = initialState, action) {
  switch (action.type) {
    case SIGNUP_SUCCESS:
    {
      const { data = null, error = null, isLoading = null } = action.payload;
      if (error) {
        return {
          ...state,
          error,
        };
      }

      const newState = {
        ...state,
        data,
        isLoading,
        error,
      };

      return newState;
    }
    case SIGNUP_FAIL:
      return {
        ...state,
        isLoading: false,
        error: action.payload.error,
      };
    case SIGNUP_INPROGRESS:
      return {
        ...state,
        isLoading: true,
        error: null,
      };
    default:
      return state;
  }
}
