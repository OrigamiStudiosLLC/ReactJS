import {
  FETCH_RECOMMENDED_MOVIES_REQUEST,
  ACTIVATE_LOADER,
  FETCH_RECOMMENDED_MOVIES_REPLACE_MOVIE,
  FETCH_RECOMMENDED_MOVIES_CLEAN,
} from '../constants';

function fetchMoviesRequest(requestPayload) {
  return { type: FETCH_RECOMMENDED_MOVIES_REQUEST, requestPayload };
}

function loaderIndicator() {
  return { type: ACTIVATE_LOADER };
}

export function removeMovieFromDisplay(payload) {
  return { type: FETCH_RECOMMENDED_MOVIES_REPLACE_MOVIE, payload };
}

export function clearRecommendedMovies() {
  return { type: FETCH_RECOMMENDED_MOVIES_CLEAN };
}

export function fetchRecommendedMovies(payload) {
  return (dispatch) => {
    dispatch(fetchMoviesRequest(payload));
    if (!payload.isLoadBackupMovies) {
      dispatch(loaderIndicator());
    }
  };
}
