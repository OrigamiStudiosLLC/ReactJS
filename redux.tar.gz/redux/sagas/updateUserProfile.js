/* eslint no-underscore-dangle: 0 */
import { call, put, takeEvery } from 'redux-saga/effects';
import { isJson } from '../../Utils';
import { requestUpdateUserProfile } from '../../services/updateUserProfile';
import {
  UPDATE_USER_PROFILE_REQUEST,
  UPDATE_USER_PROFILE_SUCCESS,
  UPDATE_USER_PROFILE_FAIL,
} from '../constants';

function updateUserProfileSuccess(payload) {
  return { type: UPDATE_USER_PROFILE_SUCCESS, payload };
}

function updateUserProfileFail(payload) {
  return { type: UPDATE_USER_PROFILE_FAIL, payload };
}

function* updateUserProfile(aPayload) {
  const { requestPayload } = aPayload;
  const url = 'me/profile';

  try {
    const resBody = yield call(requestUpdateUserProfile, { url, requestPayload });

    let responseData;

    if (isJson(resBody._bodyText)) {
      responseData = JSON.parse(resBody._bodyText);
    } else {
      responseData = { message: resBody._bodyText };
    }

    let payload;

    if (!resBody.ok) {
      payload = {
        error: responseData,
      };
      yield put(updateUserProfileFail(payload));
    } else {
      payload = {
        data: responseData,
      };
      yield put(updateUserProfileSuccess(payload));
    }
  } catch (error) {
    yield put(updateUserProfileFail({ error }));
  }
}

export default function* updateUserProfileSaga() {
  yield takeEvery(UPDATE_USER_PROFILE_REQUEST, updateUserProfile);
}
