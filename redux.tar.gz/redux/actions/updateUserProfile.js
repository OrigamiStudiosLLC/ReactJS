import {
  UPDATE_USER_PROFILE_REQUEST,
  UPDATE_USER_PROFILE_INPROGRESS,
} from '../constants';

function updateUserProfileRequest(requestPayload) {
  return {
    type: UPDATE_USER_PROFILE_REQUEST,
    requestPayload,
  };
}

export default function updateUserProfile(requestPayload = {}) {
  return (dispatch) => {
    dispatch(updateUserProfileRequest(requestPayload));
    dispatch({ type: UPDATE_USER_PROFILE_INPROGRESS });
  };
}
