/* eslint no-underscore-dangle: 0 */
import { call, put, takeEvery } from 'redux-saga/effects';
import { fetchMoviesForTaste } from '../../services/taste';
import {
  FETCH_MOVIES_FOR_TASTE_REQUEST,
  FETCH_MOVIES_FOR_TASTE_SUCCESS,
  FETCH_MOVIES_FOR_TASTE_FAIL,

} from '../constants';
import {
  isJson,
} from '../../Utils';

function fetchTasteMoviesSuccess(payload) {
  return { type: FETCH_MOVIES_FOR_TASTE_SUCCESS, payload };
}

function fetchTasteMoviesFail(payload) {
  return { type: FETCH_MOVIES_FOR_TASTE_FAIL, payload };
}

function* fetchMoviesForTasteRequest() {
  const url = 'me/quickrate';
  const queryString = {
    type: 'rating',
  };
  try {
    let responseData;
    let payload;

    const resp = yield call(fetchMoviesForTaste, { url, queryString });

    if (isJson(resp._bodyText)) {
      responseData = JSON.parse(resp._bodyText);
    } else {
      responseData = { message: resp._bodyText };
    }

    if (!resp.ok) {
      payload = {
        error: responseData,
      };
      yield put(fetchTasteMoviesFail(payload));
    } else {
      payload = {
        data: responseData,
      };

      if (responseData.status) {
        yield put(fetchTasteMoviesFail({ error: { message: 'wait error' } }));
      } else {
        const moviesForTaste = responseData.batch;
        yield put(fetchTasteMoviesSuccess({ moviesForTaste }));
      }
    }
  } catch (error) {
    yield put(fetchTasteMoviesFail({ error }));
  }
}

export default function* tasteSaga() {
  yield takeEvery(FETCH_MOVIES_FOR_TASTE_REQUEST, fetchMoviesForTasteRequest);
}
