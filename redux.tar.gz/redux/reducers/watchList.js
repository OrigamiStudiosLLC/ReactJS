import {
  FETCH_WATCHLIST_MOVIES_SUCCESS,
  FETCH_WATCHLIST_MOVIES_FAIL,
  FETCH_WATCHLIST_MOVIES_LOADING,
  FETCH_WATCHLIST_MOVIES_CLEAR,
} from '../constants';

const initialState = {
  movies: [],
  isLoading: false,
  error: null,
  offset: 0,
  next: false,
  prev: false,
  total: 0,
};

export default function (state = initialState, action) {
  switch (action.type) {
    case FETCH_WATCHLIST_MOVIES_SUCCESS:
    {
      const {
        movies, offset, next, prev, total,
      } = action.payload;

      const newState = {
        ...state,
        movies,
        offset,
        next,
        prev,
        total,
        isLoading: false,
      };

      if (offset) {
        newState.movies = [...state.movies, ...movies];
      }

      return newState;
    }
    case FETCH_WATCHLIST_MOVIES_FAIL:
      return {
        ...state,
        isLoading: false,
        error: action.payload.error,
      };
    case FETCH_WATCHLIST_MOVIES_LOADING:
      return {
        ...state,
        isLoading: true,
      };
    case FETCH_WATCHLIST_MOVIES_CLEAR:
      return {
        ...initialState,
      };
    default:
      return state;
  }
}
